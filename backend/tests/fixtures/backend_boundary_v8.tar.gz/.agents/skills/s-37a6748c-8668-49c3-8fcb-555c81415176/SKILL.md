---
name: s-37a6748c-8668-49c3-8fcb-555c81415176
description: "按规则检查文档"
---
BODY_MARKER_P1：逐项核对原文，再给结论。